// resources/views/account/deletion_error.blade.php
<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<title>Suppression de compte</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head><body style="font-family:system-ui;margin:40px">
  <h1>Suppression de compte</h1>
  <p style="color:#b91c1c">{{ $message ?? 'Une erreur est survenue.' }}</p>
</body></html>
