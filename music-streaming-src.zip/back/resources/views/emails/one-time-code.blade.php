<p>Bonjour,</p>
<p>Voici votre code <strong>{{ $purpose }}</strong> :</p>
<h2 style="font-family:monospace;letter-spacing:4px">{{ $code }}</h2>
<p>Il expire dans 10 minutes.</p>
<p>Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>
