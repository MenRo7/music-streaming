// types.ts
export interface Song {
    _id: string;
    title: string;
    artist: string;
    description?: string;
    audioUrl: string;
  }
  